package com.example.finals

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
