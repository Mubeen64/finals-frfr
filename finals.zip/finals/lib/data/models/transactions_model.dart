import 'dart:convert';

class TransactionsModel {
  String? id;
  String? title;
  String? icon;
  int? amount;
  String? date;
  bool? transactionType;
  TransactionsModel({
    this.id,
    this.title,
    this.icon,
    this.amount,
    this.date,
    this.transactionType,
  });

  TransactionsModel copyWith({
    String? id,
    String? title,
    String? icon,
    int? amount,
    String? date,
    bool? transactionType,
  }) {
    return TransactionsModel(
      id: id ?? this.id,
      title: title ?? this.title,
      icon: icon ?? this.icon,
      amount: amount ?? this.amount,
      date: date ?? this.date,
      transactionType: transactionType ?? this.transactionType,
    );
  }

  Map<String, dynamic> toMap() {
    return <String, dynamic>{
      'id': id,
      'title': title,
      'icon': icon,
      'amount': amount,
      'date': date,
      'transactionType': transactionType,
    };
  }

  factory TransactionsModel.fromMap(Map<String, dynamic> map) {
    return TransactionsModel(
      id: map['id'] != null ? map['id'] as String : null,
      title: map['title'] != null ? map['title'] as String : null,
      icon: map['icon'] != null ? map['icon'] as String : null,
      amount: map['amount'] != null ? map['amount'] as int : null,
      date: map['date'] != null ? map['date'] as String : null,
      transactionType: map['transactionType'] != null
          ? map['transactionType'] as bool
          : null,
    );
  }

  String toJson() => json.encode(toMap());

  factory TransactionsModel.fromJson(String source) =>
      TransactionsModel.fromMap(json.decode(source) as Map<String, dynamic>);

  @override
  String toString() {
    return 'TransactionsModel(id: $id, title: $title, icon: $icon, amount: $amount, date: $date, transactionType: $transactionType)';
  }

  @override
  bool operator ==(covariant TransactionsModel other) {
    if (identical(this, other)) return true;

    return other.id == id &&
        other.title == title &&
        other.icon == icon &&
        other.amount == amount &&
        other.date == date &&
        other.transactionType == transactionType;
  }

  @override
  int get hashCode {
    return id.hashCode ^
        title.hashCode ^
        icon.hashCode ^
        amount.hashCode ^
        date.hashCode ^
        transactionType.hashCode;
  }
}
