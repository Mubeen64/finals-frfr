import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:finals/data/models/transactions_model.dart';

class TransactionsRepository {
  Future<List<TransactionsModel>> getTransactions() async {
    final transactions = FirebaseFirestore.instance.collection('transactions');

    try {
      final snapshot = await transactions.get();
      return snapshot.docs
          .map((doc) => TransactionsModel.fromJson(doc.data() as String))
          .toList();
    } catch (e) {
      throw Exception(e);
    }
  }
}
