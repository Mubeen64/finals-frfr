import 'package:finals/business%20logic/cubits/transactions/transactions_cubit.dart';
import 'package:finals/firebase_options.dart';
import 'package:finals/presentation/screens/navigation_screen.dart';
import 'package:finals/presentation/screens/second_question_screen.dart';
import 'package:finals/presentation/screens/transactions_screen.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  runApp(const MainApp());
}

class MainApp extends StatelessWidget {
  const MainApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiBlocProvider(
      providers: [
        BlocProvider(create: (_) => TransactionsCubit()),
      ],
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        initialRoute: '/navigationScreen',
        routes: {
          '/navigationScreen': (context) => const NavigationScreen(),
          '/transactionsScreen': (context) => const TransactionsScreen(),
          '/secondQuestionScreen': (context) => const SecondQuestionScreen(),
        },
      ),
    );
  }
}
