import 'package:flutter/material.dart';

class ColorOption extends StatelessWidget {
  const ColorOption(
      {super.key, required this.topColor, required this.bottomColor});
  final Color topColor;
  final Color bottomColor;

  @override
  Widget build(BuildContext context) {
    return CircleAvatar(
      radius: MediaQuery.sizeOf(context).width * 0.018,
      child: ClipOval(
        child: Column(
          children: <Widget>[
            Expanded(
              child: Container(color: topColor),
            ),
            const Divider(height: 2, thickness: 2, color: Colors.grey),
            Expanded(
              child: Container(color: bottomColor),
            ),
          ],
        ),
      ),
    );
  }
}
