import 'package:flutter/material.dart';

class NavigationScreen extends StatelessWidget {
  const NavigationScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            SizedBox(width: MediaQuery.sizeOf(context).width),
            ElevatedButton(
              onPressed: () {
                Navigator.pushNamed(context, '/transactionsScreen');
              },
              child: const Text('Question(01)'),
            ),
            const SizedBox(height: 10),
            ElevatedButton(
              onPressed: () {
                Navigator.pushNamed(context, '/secondQuestionScreen');
              },
              child: const Text('Question(02)'),
            ),
          ],
        ),
      ),
    );
  }
}
