import 'package:finals/business%20logic/cubits/transactions/transactions_cubit.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class TransactionsScreen extends StatelessWidget {
  const TransactionsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[200],
      appBar: AppBar(
        backgroundColor: Colors.grey[200],
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () {},
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.more_horiz),
            onPressed: () {},
          ),
        ],
      ),
      body: Column(
        children: [
          // header row
          Padding(
            padding: EdgeInsets.symmetric(
                horizontal: MediaQuery.sizeOf(context).width * 0.05),
            child: const Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              mainAxisSize: MainAxisSize.max,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "MONDAY",
                      style: TextStyle(
                        fontSize: 15,
                        color: Colors.grey,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Text(
                      "17 Nov",
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
                Text(
                  '\$2,2983',
                  style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      color: Colors.blueAccent),
                ),
              ],
            ),
          ),

          // space
          SizedBox(height: MediaQuery.sizeOf(context).height * 0.02),

          // transactions container
          BlocBuilder<TransactionsCubit, TransactionsState>(
            builder: (context, state) {
              if (state is TransactionsLoading) {
                return const Center(child: CircularProgressIndicator());
              } else if (state is TransactionsLoaded) {
                return Container(
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(25),
                  ),
                  child: Padding(
                    padding: EdgeInsets.symmetric(
                      horizontal: MediaQuery.sizeOf(context).width * 0.05,
                    ),
                    child: Column(
                      // transactions heading
                      children: [
                        SizedBox(
                            height: MediaQuery.sizeOf(context).height * 0.02),
                        const Row(
                          children: [
                            Text(
                              "Transactions",
                              style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                              ),
                            )
                          ],
                        ),
                        SizedBox(
                            height: MediaQuery.sizeOf(context).height * 0.02),
                        SizedBox(
                          child: ListView.builder(
                            itemCount: state.transactions.length,
                            itemBuilder: (context, index) {
                              return ListTile(
                                leading: Container(
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(50),
                                    color: Colors.grey[200],
                                  ),
                                  child: Image.network(
                                    state.transactions[index].icon ??
                                        'https://picsum.photos/250?image=9',
                                    width: 50,
                                    height: 50,
                                  ),
                                ),
                                title: Text(
                                  state.transactions[index].title ?? 'null',
                                  style: const TextStyle(
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                subtitle: Text(
                                    state.transactions[index].date ?? 'null',
                                    style: const TextStyle(
                                      color: Colors.grey,
                                      fontSize: 12,
                                    )),
                                trailing: Text(
                                  '${state.transactions[index].transactionType == true ? '-' : '+'}\$${state.transactions[index].amount.toString()}',
                                  style: TextStyle(
                                    color: state.transactions[index]
                                                .transactionType ==
                                            true
                                        ? Colors.red
                                        : Colors.blue,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 18,
                                  ),
                                ),
                              );
                            },
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              } else {
                return Center(
                    child: TextButton(
                  child: const Text('Reload'),
                  onPressed: () {
                    context.read<TransactionsCubit>().getTransactions();
                  },
                ));
              }
            },
          ),
        ],
      ),
    );
  }
}
