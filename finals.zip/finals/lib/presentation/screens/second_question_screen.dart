import 'package:finals/presentation/widgets/color_option.dart';
import 'package:flutter/material.dart';

class SecondQuestionScreen extends StatelessWidget {
  const SecondQuestionScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: SafeArea(
        child: Padding(
          padding: EdgeInsets.symmetric(
              horizontal: MediaQuery.sizeOf(context).width * 0.013),
          child: Column(
            mainAxisSize: MainAxisSize.max,
            children: [
              // header
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text(
                    "Recommended for\nyour devices",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 30,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  TextButton(
                    child: const Text(
                      "See all",
                      style: TextStyle(color: Colors.blue),
                    ),
                    onPressed: () {},
                  ),
                ],
              ),

              // space
              SizedBox(height: MediaQuery.sizeOf(context).height * 0.023),

              // container thingy
              Expanded(
                child: Container(
                  width: double.maxFinite,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    // color: const Color.fromARGB(1, 28, 28, 30),
                    color: Colors.grey.shade900,
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.max,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      // bookmark
                      Row(
                        mainAxisSize: MainAxisSize.max,
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          IconButton(
                            onPressed: () {},
                            icon: const Icon(
                              Icons.bookmark_border,
                              color: Colors.blue,
                            ),
                          ),
                        ],
                      ),

                      // space
                      SizedBox(
                        height: MediaQuery.sizeOf(context).height * 0.05,
                      ),

                      // image
                      Image.asset(
                        'assets/images/headphones.png',
                      ),

                      // space
                      SizedBox(
                        height: MediaQuery.sizeOf(context).height * 0.05,
                      ),

                      // free engraving
                      Text(
                        "Free Engraving",
                        style: TextStyle(
                          color: Colors.yellow.shade700,
                          fontSize: 12,
                          fontWeight: FontWeight.w500,
                        ),
                      ),

                      // space
                      SizedBox(
                        height: MediaQuery.sizeOf(context).height * 0.0025,
                      ),

                      // airpods max
                      const Text(
                        "AirPods Max — Silver",
                        style: TextStyle(
                          color: Colors.white,
                        ),
                      ),

                      // space
                      SizedBox(
                        height: MediaQuery.sizeOf(context).height * 0.0025,
                      ),

                      // price
                      const Text(
                        "A\$899.00",
                        style: TextStyle(
                          color: Colors.white,
                        ),
                      ),

                      // space
                      SizedBox(
                        height: MediaQuery.sizeOf(context).height * 0.0025,
                      ),

                      // row of colors
                      Row(
                        mainAxisSize: MainAxisSize.max,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          const ColorOption(
                            topColor: Colors.white,
                            bottomColor: Colors.yellow,
                          ),
                          SizedBox(
                            width: MediaQuery.sizeOf(context).width * 0.018,
                          ),
                          const ColorOption(
                            topColor: Colors.white,
                            bottomColor: Colors.yellow,
                          ),
                          SizedBox(
                            width: MediaQuery.sizeOf(context).width * 0.018,
                          ),
                          const ColorOption(
                            topColor: Colors.white,
                            bottomColor: Colors.yellow,
                          ),
                          SizedBox(
                            width: MediaQuery.sizeOf(context).width * 0.018,
                          ),
                          const ColorOption(
                            topColor: Colors.white,
                            bottomColor: Colors.yellow,
                          ),
                          SizedBox(
                            width: MediaQuery.sizeOf(context).width * 0.018,
                          ),
                          InkWell(
                            onTap: () {},
                            child: const Text(
                              "+1 more",
                              style: TextStyle(
                                color: Colors.grey,
                                fontSize: 12,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),

              // space
              SizedBox(height: MediaQuery.sizeOf(context).height * 0.009),
            ],
          ),
        ),
      ),
    );
  }
}

// class ColorOption extends StatelessWidget {
//   final Color color;

//   const ColorOption(this.color, {super.key});

//   @override
//   Widget build(BuildContext context) {
//     return CircleAvatar(
//       backgroundColor: color,
//       radius: MediaQuery.sizeOf(context).width * 0.018,
//     );
//   }
// }
