import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:finals/data/models/transactions_model.dart';
import 'package:finals/data/repositories/transactions_repo.dart';

part 'transactions_state.dart';

class TransactionsCubit extends Cubit<TransactionsState> {
  TransactionsCubit() : super(TransactionsInitial());

  final TransactionsRepository _transactionsRepository =
      TransactionsRepository();

  void getTransactions() async {
    emit(TransactionsLoading());
    try {
      final transactions = await _transactionsRepository.getTransactions();
      emit(TransactionsLoaded(transactions));
    } catch (e) {
      emit(TransactionsError(e.toString()));
    }
  }
}
